User Guide
==========
.. toctree::
   :maxdepth: 2

   lz4
   lz4.frame
   lz4.block
   lz4.stream
